REVIZOR.FUN – FINÁLNY PROJEKT

OBSAH
- index.html = verejná stránka
- functions/ = serverové API pre hlásenia a Admin
- schema.sql = Cloudflare D1 databáza
- _routes.json = Functions sa spúšťajú iba na /api/*
- README_PRE_TEBA.txt = tento návod

HLÁSENIA
- používateľ vyberie linku, smer a zastávku
- 4-miestny kód 2224 -> iba Revízor
- akýkoľvek iný 4-miestny kód -> iba Slabá Wi-Fi
- po kliknutí na voľbu sa hlásenie automaticky odošle
- uloží sa čas, linka, smer, zastávka a typ

ADMIN
- Admin je vpravo dole
- heslo nie je v index.html ani v GitHube
- prihlasovanie overuje server
- po prihlásení vidíš všetky hlásenia
- funguje aj odhlásenie

NASADENIE NA CLOUDFLARE PAGES
1. Nahraj obsah tohto projektu do GitHub repository.
2. Cloudflare -> Workers & Pages -> Create application -> Pages -> Connect to Git.
3. Vyber GitHub repository a branch main.
4. Build command nechaj prázdny.
5. Build output directory nechaj ako koreň projektu.
6. Deploy.
7. Vytvor D1 databázu, napr. revizor-db.
8. V D1 SQL konzole spusti celý obsah schema.sql.
9. Pages -> Settings -> Bindings -> Add -> D1 database.
   Variable name: DB
   Database: revizor-db
10. Pages -> Settings -> Variables and Secrets -> Add.
    ADMIN_USER = admin
    ADMIN_PASSWORD = tvoje vlastné dlhé heslo
    ADMIN_PASSWORD nastav ako Encrypt/Secret.
11. Po pridaní secrets/bindingu urob nový deploy.
12. Pages -> Custom domains -> Set up a domain -> www.revizor.fun.

HESLO
- nepíš ho do index.html
- nepíš ho do JavaScriptu
- neukladaj ho do GitHubu
- ulož ho iba v Cloudflare ako Encrypt/Secret

POZNÁMKA
Žiadny systém nie je doslova 100 % bezpečný. Toto riešenie však drží admin heslo mimo verejného HTML a používa serverové session cookies a databázu.
